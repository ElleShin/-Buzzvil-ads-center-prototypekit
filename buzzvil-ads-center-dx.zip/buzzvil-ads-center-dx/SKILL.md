---
name: buzzvil-ads-center-dx
description: >
  Buzzvil Ads Center(ads.buzzvil.com) UI 목업 생성 스킬.
  사용자가 요구사항을 입력하면 Figma MCP로 실제 화면을 읽고
  광고센터의 UXUI를 정확히 재현한 인터랙티브 HTML 목업을 생성한다.
  화면 요청 시 이미지 업로드나 별도 레퍼런스 없이 자동으로 동작한다.
  한국어 요청에도 동일하게 동작한다 (예: "정산 페이지 만들어줘", "라이브커머스 목록 화면").
---

# Buzzvil Ads Center DX — UI 목업 생성 스킬

## 스킬 목적
이 스킬을 사용하는 사람은 **요구사항 텍스트만 입력**하면 된다.
Claude가 Figma MCP로 실제 화면 구조를 읽고, 광고센터 UXUI를 정확히 재현한 HTML 목업을 자동으로 만들어준다.
사용자가 이미지를 업로드하거나 레퍼런스를 찾아올 필요가 없다.

---

## 신규 화면 생성 원칙 (Figma에 없는 화면 요청 시)

사용자가 **선불충전, 크레딧 관리, 새로운 상품 유형** 등 Figma 레퍼런스에 없는 화면을 요청할 수 있다.
이때 절대 "레퍼런스가 없다"고 거절하지 말고, 아래 원칙으로 새 화면을 생성한다.

### 1. UX/UI 관점에서 가장 유사한 화면을 레퍼런스로 선택
고정된 매핑 테이블이 아니라, **요구사항의 목적과 구조를 파악해서** 기존 화면 중 가장 알맞은 것을 Claude가 직접 판단한다.

판단 기준 예시 (절대적이지 않음, 문맥에 따라 유연하게 적용):
- 정보를 **목록으로 조회**하는 화면 → 라이브커머스/협력광고/정산 목록 패턴 참고
- **금액/잔액/충전/결제** 관련 → 정산 페이지의 카드+테이블 구조 참고 가능
- **단계별 생성/설정** 플로우 → 협력광고/라이브커머스 생성 패턴 참고
- **데이터 분석/통계** → 리포트 패턴 참고
- **멤버/권한/그룹** 관리 → 그룹 관리/멤버 초대 패턴 참고
- **카드형 상품 목록** → 카탈로그 패턴 참고

단, 하나의 화면이 여러 패턴을 조합할 수도 있다. 예를 들어 선불충전 화면은 "잔액 요약 카드 + 충전 내역 테이블 + 충전하기 폼"을 조합한 새로운 구성이 될 수 있다.

### 2. 레퍼런스로 선택한 화면을 Figma MCP로 읽기
`references/screen-patterns.md`의 node-id로 `get_design_context` 호출 → 레이아웃 구조, 컴포넌트 조합, 간격 패턴 추출 후 적용

### 3. 디자인 일관성 원칙 (모든 화면에 동일하게 적용)
- 동일한 topnav, 사이드바 구조
- 동일한 색상 토큰, 타이포그래피, 간격
- 동일한 카드/테이블/버튼/뱃지 패턴
- Google Material Symbols Rounded, Fill=1, wght=500 아이콘

### 4. 절대 하지 말 것
- "Figma에 해당 화면이 없어서 만들기 어렵습니다" — ❌
- 사용자에게 레퍼런스 이미지나 추가 정보 요청 — ❌
- 기존 화면과 다른 디자인 언어 사용 — ❌
- 특정 패턴에 기계적으로 매핑 — ❌ (UX 문맥을 직접 판단할 것)

사용자는 요구사항만 입력하면 된다. Claude가 UX/UI 관점에서 알아서 판단하고 만들어준다.

---

## 실행 순서 (매 요청마다 반드시 이 순서를 따를 것)

### Step 1 — Figma에서 관련 화면 읽기
`references/screen-patterns.md`의 URL 목록에서 요청과 가장 관련 있는 화면의 node-id를 찾는다.
Figma MCP `get_design_context`를 호출한다:

```
fileKey: ADytF6TeqZH0ggDEt43c1E
nodeId: [screen-patterns.md에서 찾은 node-id]
clientFrameworks: react,next.js
clientLanguages: typescript,css
```

- 사용자가 Figma URL을 직접 주는 경우: URL의 `node-id` 파라미터를 추출해서 바로 호출
- 관련 화면이 여러 개인 경우: 가장 유사한 화면 1~2개만 읽는다
- Figma MCP가 연결되지 않은 환경: `references/screen-patterns.md`의 실측값만으로 구현

### Step 2 — HTML 목업 생성
Figma에서 읽은 구조 + `references/screen-patterns.md` 실측값을 기반으로 HTML을 작성한다.

**출력 규칙:**
- 단일 `.html` 파일 (CSS + JS 인라인)
- 완전히 인터랙티브 (필터, 탭, 모달, 페이지네이션 모두 동작)
- 다운로드 후 브라우저에서 바로 열 수 있어야 함
- `/mnt/user-data/outputs/[화면명].html`로 저장 후 `present_files`로 공유

### Step 3 — TSX 파일 생성 (요청 시에만)
사용자가 코드 구현을 원할 때만 `.tsx` 파일을 추가로 생성한다.

---

## 아이콘 규칙 — Google Material Symbols Rounded (Fill + wght 500)

### CDN (모든 HTML 목업 `<head>`에 반드시 포함)
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet">
```

### 기본 CSS (모든 HTML 목업 `<style>`에 반드시 포함)
```css
/* 기본: Fill=1, wght=500, Rounded */
.icon {
  font-family: 'Material Symbols Rounded';
  font-weight: normal; font-style: normal;
  font-size: 24px; line-height: 1;
  display: inline-block; white-space: nowrap;
  -webkit-font-smoothing: antialiased;
  font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24;
  user-select: none;
}
/* 크기 variants */
.icon-40 { font-size: 40px; font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 40; }
.icon-24 { font-size: 24px; font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 24; }
.icon-20 { font-size: 20px; font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 20; }
.icon-18 { font-size: 18px; font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 20; }
.icon-16 { font-size: 16px; font-variation-settings: 'FILL' 1, 'wght' 500, 'GRAD' 0, 'opsz' 20; }
```

### 사용법
```html
<span class="icon">아이콘명</span>
<span class="icon icon-20">아이콘명</span>
```

### 아이콘 매핑 — Buzzvil Ads Center 전체

**사이드바 메뉴**
| 용도 | 아이콘명 |
|------|---------|
| 라이브커머스 | `smart_display` |
| 협력 광고 | `handshake` |
| 리테일 미디어 | `storefront` |
| 노출형 배너 | `ad_units` |
| 리포트 | `bar_chart` |
| 카탈로그 | `sell` |
| 타겟팅 | `ads_click` |
| 정산 | `receipt_long` |
| 멤버 | `group` |
| 운영 그룹 정보 | `settings` |

**UI 액션**
| 용도 | 아이콘명 |
|------|---------|
| 추가/생성 | `add` |
| 검색 | `search` |
| 다운로드 | `download` |
| 업로드 | `upload` |
| 닫기/삭제 | `close` |
| 수정/편집 | `edit` |
| 삭제 | `delete` |
| 필터 | `filter_list` |
| 정렬 | `sort` |
| 새로고침 | `refresh` |
| 더보기(chevron 하) | `expand_more` |
| 더보기(chevron 상) | `expand_less` |
| 좌측 화살표 | `chevron_left` |
| 우측 화살표 | `chevron_right` |
| 뒤로가기 | `arrow_back` |
| 앞으로 | `arrow_forward` |
| 외부 링크 | `open_in_new` |
| 복사 | `content_copy` |
| 공유 | `share` |

**상태 / 캠페인**
| 용도 | 아이콘명 |
|------|---------|
| 집행중 | `play_circle` |
| 집행완료 | `check_circle` |
| 집행예정 | `schedule` |
| 심사중 | `pending` |
| 심사 전/준비중 | `edit_note` |
| 반려 | `cancel` |
| 일시정지 | `pause_circle` |
| 집행중지 | `stop_circle` |

**정보 / 피드백**
| 용도 | 아이콘명 |
|------|---------|
| 정보 | `info` |
| 경고 | `warning` |
| 에러 | `error` |
| 성공 | `check_circle` |
| 질문/도움말 | `help` |
| 공지 | `notifications` |

**사용자 / 계정**
| 용도 | 아이콘명 |
|------|---------|
| 유저 (단일) | `person` |
| 유저 (복수) | `group` |
| 이메일 | `mail` |
| 전화 | `phone` |
| 비밀번호/잠금 | `lock` |
| 로그아웃 | `logout` |

**기타**
| 용도 | 아이콘명 |
|------|---------|
| 달력 | `calendar_month` |
| 시계 | `schedule` |
| 이미지 | `image` |
| 동영상 | `smart_display` |
| 링크 | `link` |
| 파일 | `description` |
| 차트/그래프 | `bar_chart` |
| 빈 상태 | `search_off` |
| 별표/즐겨찾기 | `star` |
| 태그 | `label` |
| 금액/정산 | `payments` |
| 체크박스 선택 | `check_box` |
| 라디오 선택 | `radio_button_checked` |

---

## HTML 목업 작성 규칙

### 레이아웃 Shell (반드시 이 구조 사용)
```html
<style>
  /* 전체 배경 */
  body { background: #f1f5f9; font-family: 'Pretendard Variable', -apple-system, sans-serif; }

  /* Topnav */
  .topnav {
    height: 56px; background: #fff;
    box-shadow: inset 0px -1px 0px 0px #CBD5E1;
    position: fixed; top: 0; left: 0; right: 0; z-index: 100;
    display: flex; align-items: center; padding: 0 16px;
  }

  /* 사이드바 */
  .sidebar {
    width: 240px; background: #fff;
    box-shadow: inset -1px 0px 0px 0px #CBD5E1;
    position: fixed; top: 56px; left: 0; bottom: 0;
    padding: 0 6px; overflow-y: auto;
  }

  /* 메인 콘텐츠 */
  .main {
    margin-left: 240px;
    padding: 32px;
    padding-top: calc(56px + 32px);
    min-height: 100vh;
  }
</style>
```

### 카드
```css
background: #fff;
border: 1px solid #CBD5E1;
border-radius: 8px;
padding: 24px;
```

### 테이블 헤더
```css
background: #f1f5f9;
box-shadow: inset 0px 1px 0px 0px #CBD5E1, inset 0px -2px 0px 0px #CBD5E1;
padding: 12px;
font-size: 12px; font-weight: 700; color: #64748b;
```

### 테이블 행
```css
background: #fff;
box-shadow: inset 0px -1px 0px 0px rgba(97, 117, 134, 0.2);
padding: 12px;
font-size: 14px; color: #334155;
```

### 버튼
```css
/* Primary */
background: #3b82f6; color: #fff;
padding: 8px 12px; border-radius: 8px;
font-size: 14px; font-weight: 700;

/* Mono */
background: #fff; border: 1px solid #CBD5E1;
color: #64748b; padding: 8px 12px;

/* Ghost Blue (테이블 액션) */
background: #dbeafe; color: #3b82f6;
padding: 4px 8px; border-radius: 8px;
```

### 색상 (절대 다른 값 사용 금지)
```
배경:    #f1f5f9
white:   #ffffff
primary: #3b82f6
border:  #CBD5E1

text-high:    #0f172a
text-em:      #334155
text-default: #64748b
text-subtle:  #94a3b8
```

---

## Reference Files

| 파일 | 용도 |
|------|------|
| `references/screen-patterns.md` | Figma 실측값, URL 목록 — 항상 참고 |
| `references/design-tokens.md` | 디자인 토큰 전체 목록 |
| `references/components.md` | 컴포넌트 사용법 (TSX 작성 시) |
| `references/layout-patterns.md` | 레이아웃 패턴 |
| `references/code-conventions.md` | 코드 컨벤션 (TSX 작성 시) |

---

## TSX 작성 규칙 (요청 시에만)

- `"use client"` 필수 (hooks/인터랙션 있을 때)
- 색상: 항상 토큰 클래스 사용 (`bg-primary-bg-default`, `text-base-fg-text-moderate-emphasis`)
- 절대 hex 하드코딩 금지 (`bg-blue-500`, `#3b82f6` 직접 사용 금지)
- 컴포넌트 import:
  ```tsx
  import { Button } from "@/components/ui/button/button";
  import { Badge } from "@/components/ui/badge/badge";
  import { Input } from "@/components/ui/input/input";
  import { Modal } from "@/components/ui/modal/modal";
  import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table/table";
  import { Frame } from "@/components/ui/frame/frame";
  ```

---

## 자주 만드는 화면 패턴 빠른 참고

| 요청 키워드 | 참고할 Figma node-id |
|------------|---------------------|
| 로그인 | `10174-96050` |
| 회원가입 | `10396-195021` |
| 라이브커머스 목록 | `368-8357` |
| 라이브커머스 생성 | `485-21579`, `627-22005` |
| 협력광고 목록 | `3296-56991` |
| 협력광고 생성 | `3350-96878`, `3227-36547` |
| 정산 | `9938-248877` |
| 리포트 | `8758-289808` |
| 카탈로그 | `6969-133673` |
| 멤버/그룹 관리 | `10174-95367`, `10791-127711` |
| 사이드바 | `6-11124` |
