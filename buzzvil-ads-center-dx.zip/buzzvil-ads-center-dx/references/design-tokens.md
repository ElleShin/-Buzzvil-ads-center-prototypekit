# Design Tokens Reference

Source of truth: `src/styles/buzzvil-tokens.css`
Consumed via: `src/styles/globals.css` Tailwind `@theme` block

---

## Color Tokens → Tailwind Classes

### Primary (Blue brand)
| Token | Tailwind class | Value |
|-------|---------------|-------|
| `--color-primary-bg-default` | `bg-primary-bg-default` | #3b82f6 (blue-500) |
| `--color-primary-bg-emphasis` | `bg-primary-bg-emphasis` | #1d4ed8 (blue-700) |
| `--color-primary-bg-moderate-emphasis` | `bg-primary-bg-moderate-emphasis` | #1e3a8a (blue-900) |
| `--color-primary-bg-subtle-emphasis` | `bg-primary-bg-subtle-emphasis` | #dbeafe (blue-100) |
| `--color-primary-bg-subtle-moderate-emphasis` | `bg-primary-bg-subtle-moderate-emphasis` | #eff6ff (blue-50) |
| `--color-primary-fg-text-onAccent` | `text-primary-fg-text-onAccent` | #ffffff |
| `--color-primary-fg-text-default` | `text-primary-fg-text-default` | #3b82f6 |
| `--color-primary-fg-text-emphasis` | `text-primary-fg-text-emphasis` | #1d4ed8 |
| `--color-primary-stroke-default` | `border-primary-stroke-default` | #3b82f6 |

### Base (Neutral slate)
| Token | Tailwind class | Value |
|-------|---------------|-------|
| `--color-base-bg-default` | `bg-base-bg-default` | #ffffff |
| `--color-base-bg-subtle-moderate-emphasis` | `bg-base-bg-subtle-moderate-emphasis` | #f8fafc (slate-50) |
| `--color-base-bg-subtle-emphasis` | `bg-base-bg-subtle-emphasis` | #f1f5f9 (slate-100) |
| `--color-base-bg-subtle` | `bg-base-bg-subtle` | #e2e8f0 (slate-200) |
| `--color-base-bg-emphasis` | `bg-base-bg-emphasis` | #1e293b (slate-800) |
| `--color-base-fg-text-moderate-emphasis` | `text-base-fg-text-moderate-emphasis` | #0f172a (slate-900) |
| `--color-base-fg-text-emphasis` | `text-base-fg-text-emphasis` | #334155 (slate-700) |
| `--color-base-fg-text-default` | `text-base-fg-text-default` | #64748b (slate-500) |
| `--color-base-fg-text-subtle` | `text-base-fg-text-subtle` | #94a3b8 (slate-400) |
| `--color-base-stroke-subtle` | `border-base-stroke-subtle` | #cbd5e1 (slate-300) |
| `--color-base-stroke-default` | `border-base-stroke-default` | #64748b (slate-500) |

### Status — use for badges, alerts, indicators
| Status | Shape/bg class | Text class | Stroke class |
|--------|---------------|-----------|-------------|
| Success (green) | `bg-status-success-bg` | `text-status-success-fg` | `border-status-success-stroke` |
| Warning (yellow) | `bg-status-warning-bg` | `text-status-warning-fg` | `border-status-warning-stroke` |
| Error (red) | `bg-status-error-bg` | `text-status-error-fg` | `border-status-error-stroke` |
| Info (blue) | `bg-status-information-bg` | `text-status-information-fg` | `border-status-information-stroke` |
| Default (slate) | `bg-status-default-bg` | `text-status-default-fg` | `border-status-default-stroke` |
| Disabled | `bg-status-disabled-bg` | `text-status-disabled-fg` | `border-status-disabled-stroke` |
| Else (violet) | `bg-status-else-bg` | `text-status-else-fg` | `border-status-else-stroke` |

Shape defaults (solid dot/icon color):
- `text-status-success-shape-default` → green-500
- `text-status-error-shape-default` → red-500
- `text-status-warning-shape-default` → yellow-500

### Danger (destructive actions)
```
bg-danger-bg-default    → red-500
bg-danger-bg-emphasis   → red-700
bg-danger-bg-subtle     → red-200
```

---

## Typography Utilities

Defined in `globals.css` via `@layer utilities`:

```
text-title-xl     → 24px / 700 / lh 36px
text-title-lg     → 20px / 700 / lh 24px
text-title-md     → 16px / 700 / lh 20px
text-title-sm     → 14px / 700 / lh 20px
text-title-xs     → 12px / 700 / lh 16px

text-paragraph-md → 16px / 400 / lh 20px
text-paragraph-sm → 14px / 400 / lh 20px
text-paragraph-xs → 12px / 400 / lh 16px

text-caption-bold → 10px / 600 / lh 16px
text-caption-thin → 10px / 400 / lh 16px
```

---

## Spacing Scale

| Token name | CSS var | Value |
|-----------|---------|-------|
| `xxs` | `--spacing-xxs` | 2px |
| `xs` | `--spacing-xs` | 4px |
| `sm` | `--spacing-sm` | 8px |
| `md` | `--spacing-md` | 12px |
| `lg` | `--spacing-lg` | 16px |
| `xl` | `--spacing-xl` | 24px |
| `huge` | `--spacing-huge` | 32px |

Tailwind usage: `p-lg`, `gap-sm`, `mt-xl`, `px-md py-xs`, etc.

---

## Border Radius

| Token | Value | Usage |
|-------|-------|-------|
| `rounded-sm` | 4px | Small chips, tight elements |
| `rounded-md` | 8px | Buttons, inputs, cards (default) |
| `rounded-lg` | 16px | Modals, large cards |
| `rounded-pill` | 999px | Badges, tags |

---

## Shadow Tokens (CSS vars only)
```css
var(--shadow-modal-default)    /* modal drop shadow */
var(--shadow-dropdown-heavy)   /* dropdown/popover shadow */
```
Use in className: `shadow-[var(--shadow-modal-default)]`
