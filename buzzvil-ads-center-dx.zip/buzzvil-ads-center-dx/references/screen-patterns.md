# Screen Patterns — Figma 실측값 레퍼런스
> Figma MCP `get_design_context`로 직접 추출한 실제 수치.
> 절대 추론하지 말고 이 파일의 수치를 그대로 사용할 것.
> Figma 파일: `ADytF6TeqZH0ggDEt43c1E` (셀프서빙 플랫폼)

---

## 1. 전체 페이지 Shell

### 캔버스
- 기준 해상도: **1440px**
- 전체 배경색: `#f1f5f9` (base-bg-subtle-emphasis)

### Topnav
```css
height: 56px;
background: #ffffff;
box-shadow: inset 0px -1px 0px 0px #CBD5E1;
position: fixed; top: 0; left: 0; right: 0; z-index: 100;
```
- 좌측 로고: `left: 16px; top: 18px` — Mark + buzzvil 텍스트, `height: 20px, gap: 12px`
- 우측: `right: 32px; gap: 24px`
  - "이용 방법" 버튼: `bg: white, border: 1px #CBD5E1, padding: 8px 12px, border-radius: 8px, font: 14px/Bold/#64748b`
  - 세로 구분선
  - 유저: icon(20px) + 이메일(16px/Regular/#334155) + 드롭다운 버튼

### 사이드바 (GNB)
```css
width: 240px;
background: #ffffff;
box-shadow: inset -1px 0px 0px 0px #CBD5E1;
position: fixed; top: 56px; left: 0; bottom: 0;
```
비즈그룹 셀렉터 pill: `bg: #f1f5f9, border-radius: 8px, padding: 8px, gap: 8px, margin: 16px`
- 상단 레이블: `12px/Regular/#64748b`
- 그룹명: `14px/Bold/#334155`

섹션 레이블 (광고/도구/관리): `padding: 32px 24px 8px; font: 12px/Bold/#94a3b8`

Nav 아이템: `height: 48px; padding: 4px 16px`
- 내부: `gap: 8px; padding: 8px; border-radius: 8px; width: 208px`
- 비활성: `color: #64748b`
- 활성: `bg: #f1f5f9; color: #3b82f6`
- 아이콘: `24×24px`

메뉴 구성:
1. **광고**: 라이브커머스, 협력 광고, 리테일 미디어, 노출형 배너
2. **도구**: 리포트, 카탈로그, 타겟팅(예정 badge)
3. **관리**: 정산, 멤버, 운영 그룹 정보

### 메인 콘텐츠 위치
```css
position: absolute;
left: calc(16.67% + 32px);  /* 272px */
top: 88px;                  /* topnav(56) + padding(32) */
width: 1136px;
```

---

## 2. 페이지 헤더

```css
display: flex; justify-content: space-between; align-items: flex-start;
width: 1136px;
```
- 타이틀: `24px/Bold/#0f172a`
- 우측 CTA: primary 버튼

---

## 3. 카드

```css
background: #ffffff;
border: 1px solid #CBD5E1;
border-radius: 8px;
padding: 24px;
```

카드 내 레이블+값 패턴:
```
레이블:  12px / Regular / #64748b
값:      20px / Medium  / #0f172a
서브:    14px / Regular / #64748b
```

---

## 4. 테이블

테이블 헤더:
```css
background: #f1f5f9;
box-shadow: inset 0px 1px 0px 0px #CBD5E1, inset 0px -2px 0px 0px #CBD5E1;
padding: 12px;
font: 12px / Bold / #64748b;
```

테이블 행:
```css
background: #ffffff;
box-shadow: inset 0px -1px 0px 0px rgba(97, 117, 134, 0.2);  /* 연한 구분선 */
padding: 12px;
font: 14px / Regular / #334155;
```

비활성/미래 행 텍스트: `#94a3b8`

테이블 내 Ghost Blue 버튼:
```css
background: #dbeafe; color: #3b82f6;
padding: 4px 8px; border-radius: 8px; font: 14px/Bold;
```

빈 상태:
```css
display: flex; flex-direction: column; align-items: center;
padding: 64px 0; gap: 16px;
/* 일러스트: 80px, 텍스트: 16px/Bold/#94a3b8 */
```

---

## 5. 버튼 변형

| 용도 | CSS |
|------|-----|
| Primary | `bg:#3b82f6; color:white; padding:8px 12px; radius:8px; font:14px/Bold` |
| Mono | `bg:white; border:1px #CBD5E1; color:#64748b; padding:8px 12px` |
| Ghost Blue | `bg:#dbeafe; color:#3b82f6; padding:4px 8px` |
| Danger | `bg:#ef4444; color:white` |

---

## 6. Border 표현 방식 (inset shadow)

```css
하단 border:  box-shadow: inset 0px -1px 0px 0px #CBD5E1;
우측 border:  box-shadow: inset -1px 0px 0px 0px #CBD5E1;
테이블 헤더: box-shadow: inset 0px 1px 0px 0px #CBD5E1, inset 0px -2px 0px 0px #CBD5E1;
테이블 행:   box-shadow: inset 0px -1px 0px 0px rgba(97, 117, 134, 0.2);
```

---

## 7. 색상 토큰

```
primary:           #3b82f6
primary-hover:     #2563eb
primary-subtle:    #eff6ff
primary-subtle-em: #dbeafe

base-bg:           #ffffff
base-bg-subtle-em: #f1f5f9   ← 전체배경, 사이드바활성, 테이블헤더
base-bg-moderate:  #0f172a

text-high:     #0f172a
text-em:       #334155
text-default:  #64748b
text-subtle:   #94a3b8

border:        #CBD5E1
divider-row:   rgba(97, 117, 134, 0.2)
```

---

## 8. 타이포그래피

```
Font: Pretendard Variable

title-xl:  24px / 700 / lh:36px
title-lg:  20px / 700 / lh:24px
title-md:  16px / 700 / lh:20px
title-sm:  14px / 700 / lh:20px
title-xs:  12px / 700 / lh:16px

paragraph-sm: 14px / 400 / lh:20px
paragraph-xs: 12px / 400 / lh:16px

caption-bold: 10px / 600 / lh:16px
```

---

## 9. 간격

```
xs:4px  sm:8px  md:12px  lg:16px  xl:24px  huge:32px
```

---

## 10. Figma URL 목록

**파일 키:** `ADytF6TeqZH0ggDEt43c1E`

| 화면 | node-id |
|------|---------|
| 로그인 | `10174-96050` |
| 회원가입 1 | `10396-195021` |
| 회원가입 2 | `10396-195108` |
| 회원가입 3 | `10396-195192` |
| 비즈그룹 생성 | `10401-203317` |
| 비즈그룹 참여 | `10396-195247` |
| 그룹 관리 | `10174-95367` |
| 그룹 관리-비즈니스 정보 | `10174-95140` |
| 운영그룹 생성 | `11066-108648` |
| 사이드바 기본 | `6-11124` |
| 사이드바 접힘 | `2217-56227` |
| 사이드바 비즈그룹관리 | `9978-258644` |
| 설정 네비게이션바 | `28-14103` |
| 라이브커머스 목록 | `368-8357` |
| 라이브커머스 목록 2 | `368-8383` |
| 라이브커머스 생성 1-1 | `485-21579` |
| 라이브커머스 생성 1-2 | `594-22908` |
| 라이브커머스 생성 2-1 | `627-22005` |
| 라이브커머스 생성 2-2 | `368-8563` |
| 라이브커머스 디테일 | `368-7443` |
| 협력광고 목록 1 | `3296-56991` |
| 협력광고 목록 2 | `3822-115654` |
| 협력광고 목록 3 | `3933-11385` |
| 협력광고 생성-브랜드 | `11314-320123` |
| 협력광고 생성-캠페인 | `3350-96878` |
| 협력광고 생성-광고세트 | `3227-36547` |
| 협력광고 생성-소재 1 | `3213-24776` |
| 협력광고 생성-소재 2 | `4343-48153` |
| 협력광고 생성-소재 3 | `3257-40414` |
| 타겟팅 1 | `11349-321133` |
| 타겟팅 2 | `12494-290131` |
| 타겟팅 3 | `12038-241009` |
| 리포트 1 | `8758-289808` |
| 리포트 2 | `8856-63481` |
| 리포트 3 | `8871-62594` |
| 카탈로그 1 | `6969-133673` |
| 카탈로그 2 | `7326-93740` |
| 정산 목록 | `9938-248877` |
| 정산 상세 | `9938-249207` |
| 정산 확정 | `9938-250290` |
| 비즈그룹 멤버 초대 | `10791-127711` |
| 운영그룹 멤버 초대 1 | `12469-286910` |
| 운영그룹 멤버 초대 2 | `12470-287264` |
| 운영그룹 멤버 초대 3 | `11637-207475` |
| 정산 담당자 지정 1 | `11668-83320` |
| 정산 담당자 지정 2 | `11668-82907` |
| 리포트 차트 1 | `11282-304690` |
| 리포트 차트 2 | `12408-277823` |
| 리포트 차트 3 | `12716-107621` |
| 리포트 차트 4 | `12991-233207` |
