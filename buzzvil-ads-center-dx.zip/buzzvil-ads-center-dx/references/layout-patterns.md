# Layout Patterns

Visual reference: Buzzvil Ads Center (ads.buzzvil.com)
Style: Light background, blue primary, Korean labels, sidebar navigation, card-based form sections.

---

## Page Shell (Full Layout)

```tsx
export default function SomePage() {
  return (
    <div className="min-h-screen bg-base-bg-subtle-moderate-emphasis">
      {/* Top Nav */}
      <header className="h-14 bg-base-bg-default border-b border-base-stroke-subtle flex items-center px-xl gap-md sticky top-0 z-40">
        {/* Logo */}
        <div className="flex items-center gap-sm">
          <div className="w-7 h-7 rounded-md bg-primary-bg-default flex items-center justify-center">
            <span className="text-primary-fg-text-onAccent font-black text-sm">b</span>
          </div>
          <span className="text-title-sm text-base-fg-text-moderate-emphasis">buzzvil</span>
        </div>
        {/* Breadcrumb */}
        <div className="h-5 w-px bg-base-stroke-subtle mx-sm" />
        <nav className="flex items-center gap-xs text-paragraph-sm">
          <span className="text-base-fg-text-subtle">관리</span>
          <span className="text-base-fg-text-subtle mx-xs">/</span>
          <span className="text-title-sm text-base-fg-text-moderate-emphasis">페이지명</span>
        </nav>
        {/* Right actions */}
        <div className="ml-auto flex items-center gap-md">
          <span className="text-paragraph-sm text-base-fg-text-default">이용 방법</span>
          <div className="h-8 px-md flex items-center gap-xs rounded-md bg-base-bg-subtle-emphasis text-paragraph-sm text-base-fg-text-emphasis">
            ads.center@buzzvil.com ▾
          </div>
        </div>
      </header>

      {/* Body */}
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-huge max-w-[1100px]">
          {/* Page content */}
        </main>
      </div>
    </div>
  );
}
```

---

## Sidebar

```tsx
function Sidebar() {
  return (
    <aside className="w-[220px] min-h-[calc(100vh-56px)] bg-base-bg-default border-r border-base-stroke-subtle py-xl px-sm flex flex-col gap-xs">
      {/* Section heading */}
      <p className="px-md mb-xs text-caption-bold text-base-fg-text-subtle uppercase tracking-wider">광고</p>

      {/* Nav item — inactive */}
      <button className="flex items-center gap-sm px-md py-sm rounded-md text-paragraph-sm text-base-fg-text-default hover:bg-base-bg-subtle-emphasis hover:text-base-fg-text-emphasis transition-colors text-left w-full">
        <IconComponent size={16} />
        라이브커머스
      </button>

      {/* Nav item — active */}
      <button className="flex items-center gap-sm px-md py-sm rounded-md text-paragraph-sm font-semibold bg-primary-bg-subtle-moderate-emphasis text-primary-fg-text-default border border-primary-bg-subtle-emphasis text-left w-full">
        <IconComponent size={16} />
        선불 충전
      </button>
    </aside>
  );
}
```

---

## Page Header Section

```tsx
<div className="mb-xl">
  <h1 className="text-title-xl text-base-fg-text-moderate-emphasis">페이지 제목</h1>
  <p className="text-paragraph-sm text-base-fg-text-default mt-xs">
    페이지에 대한 간단한 설명
  </p>
</div>
```

---

## Card Section (Form / Stats / Content)

```tsx
<Frame className="p-xl mb-xl shadow-sm">
  {/* Card header */}
  <div className="flex items-center justify-between mb-lg">
    <h2 className="text-title-md text-base-fg-text-moderate-emphasis">섹션 제목</h2>
    <Button variant="primary" size="small">액션</Button>
  </div>

  {/* Content */}
  <div className="space-y-md">
    {/* ... */}
  </div>
</Frame>
```

---

## Summary Stat Cards (3-column)

```tsx
<div className="grid grid-cols-3 gap-md mt-lg pt-lg border-t border-base-stroke-subtle">
  <div className="bg-primary-bg-subtle-moderate-emphasis rounded-lg p-lg">
    <p className="text-caption-bold text-primary-fg-text-default mb-xs">이번 달 충전</p>
    <p className="text-title-lg text-primary-fg-text-emphasis">5,000,000원</p>
  </div>
  <div className="bg-base-bg-subtle-moderate-emphasis rounded-lg p-lg">
    <p className="text-caption-bold text-base-fg-text-default mb-xs">이번 달 사용</p>
    <p className="text-title-lg text-base-fg-text-moderate-emphasis">1,200,000원</p>
  </div>
  <div className="bg-status-success-bg rounded-lg p-lg">
    <p className="text-caption-bold text-status-success-fg mb-xs">환불 합계</p>
    <p className="text-title-lg text-status-success-fg">320,000원</p>
  </div>
</div>
```

---

## Table Page (with filter bar + pagination)

```tsx
<Frame className="overflow-hidden shadow-sm">
  {/* Filter bar */}
  <div className="flex items-center justify-between px-xl py-lg border-b border-base-stroke-subtle">
    <h2 className="text-title-sm text-base-fg-text-moderate-emphasis">목록</h2>
    <div className="flex gap-xs bg-base-bg-subtle-emphasis p-xs rounded-md">
      {["전체", "진행중", "완료"].map((f) => (
        <button
          key={f}
          className={`px-md py-xs rounded-sm text-paragraph-sm font-medium transition-all ${
            active === f
              ? "bg-base-bg-default text-base-fg-text-moderate-emphasis shadow-sm"
              : "text-base-fg-text-default hover:text-base-fg-text-emphasis"
          }`}
        >
          {f}
        </button>
      ))}
    </div>
  </div>

  {/* Table */}
  <Table>
    <TableHeader>
      <TableRow>
        <TableHead>컬럼명</TableHead>
      </TableRow>
    </TableHeader>
    <TableBody>
      {rows.map((row) => (
        <TableRow key={row.id}>
          <TableCell>{row.value}</TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>

  {/* Pagination */}
  <div className="flex items-center justify-between px-xl py-lg border-t border-base-stroke-subtle">
    <p className="text-paragraph-sm text-base-fg-text-default">총 {total}건</p>
    <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
  </div>
</Frame>
```

---

## Form Layout (Label + Input + HelperText)

```tsx
<div className="space-y-lg">
  <div className="space-y-xs">
    <Label htmlFor="name">캠페인명 <RequiredMark /></Label>
    <Input id="name" placeholder="캠페인명을 입력하세요" invalid={!!errors.name} />
    {errors.name && <HelperText error>{errors.name}</HelperText>}
  </div>

  <div className="space-y-xs">
    <Label htmlFor="budget">총 예산 <RequiredMark /></Label>
    <Input id="budget" type="number" placeholder="예산을 입력하세요 (원)" />
    <HelperText>최소 10,000원 이상 입력하세요</HelperText>
  </div>
</div>
```

---

## Modal Pattern

```tsx
// Trigger
<Button variant="primary" onClick={() => setOpen(true)}>모달 열기</Button>

// Modal
<Modal isOpen={open} onClose={() => setOpen(false)}>
  <Modal.Header title="제목" description="설명 문구입니다." />
  <Modal.Content className="px-xl py-md min-w-[480px]">
    {/* form or content */}
  </Modal.Content>
  <Modal.BottomSheet
    buttons={[
      { variant: "mono", children: "취소" },
      { variant: "primary", children: "확인", closeOnClick: false, onClick: handleConfirm },
    ]}
  />
</Modal>
```

---

## Empty State

```tsx
<div className="py-huge flex flex-col items-center justify-center text-center">
  <div className="w-12 h-12 rounded-full bg-base-bg-subtle-emphasis flex items-center justify-center mb-lg">
    <IconComponent size={24} className="text-base-fg-icon-subtle" />
  </div>
  <p className="text-title-sm text-base-fg-text-emphasis">데이터가 없습니다</p>
  <p className="text-paragraph-sm text-base-fg-text-default mt-xs">조건을 변경하거나 새로 추가해보세요</p>
  <Button variant="primary" className="mt-lg">새로 만들기</Button>
</div>
```

---

## Status / Loading State

```tsx
// Loading overlay on table
{isLoading && (
  <div className="absolute inset-0 bg-white/90 flex items-center justify-center rounded-md z-10">
    <Spinner size={32} />
  </div>
)}
```
