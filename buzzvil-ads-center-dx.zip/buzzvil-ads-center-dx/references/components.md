# Component Reference

All components live in `src/components/ui/`. They wrap shadcn/ui primitives with Buzzvil design tokens.

---

## Button

```tsx
import { Button } from "@/components/ui/button/button";

// Variants
<Button variant="primary">저장</Button>                    // blue filled (default)
<Button variant="secondary">취소</Button>                  // light blue fill
<Button variant="mono">편집</Button>                       // white with border
<Button variant="subtle">더보기</Button>                   // text only, no bg

// Intent
<Button intent="danger">삭제</Button>                      // red (use with primary/secondary)

// Size
<Button size="default">기본</Button>                       // px-lg py-sm
<Button size="small">작게</Button>                         // px-2 py-1

// State
<Button selected>선택됨</Button>
<Button loading>로딩중</Button>                            // shows Spinner, disables button
<Button disabled>비활성</Button>

// Common patterns
<Button variant="primary" onClick={handleSave}>저장</Button>
<Button variant="mono" intent="danger" onClick={handleDelete}>삭제</Button>
```

---

## Badge

```tsx
import { Badge } from "@/components/ui/badge/badge";

// Solid (default) — filled background
<Badge color="blue">진행중</Badge>
<Badge color="green">완료</Badge>
<Badge color="yellow">검토중</Badge>
<Badge color="red">오류</Badge>
<Badge color="violet">예약</Badge>
<Badge color="gray">비활성</Badge>
<Badge color="skyblue">임시저장</Badge>
<Badge color="default">기본</Badge>

// Outline — border only
<Badge variant="outline" color="blue">진행중</Badge>
<Badge variant="outline" color="green">완료</Badge>
```

---

## Input

```tsx
import { Input, InputIcon, InputTextCounter } from "@/components/ui/input/input";

// Basic
<Input placeholder="입력하세요" />
<Input type="number" placeholder="예산 입력" />

// Invalid state (red border)
<Input invalid placeholder="오류" />

// With icon
<InputIcon icon={SearchIcon} iconDirection="left">
  <Input placeholder="검색" />
</InputIcon>

// With character counter
<InputTextCounter value={text} maxLength={100}>
  <Input value={text} onChange={(e) => setText(e.target.value)} />
</InputTextCounter>
```

Shadcn input base styling (auto-applied via tokens):
- Border: `border-base-stroke-subtle`
- Focus ring: `focus-visible:ring-primary-stroke-default`
- Error: `aria-invalid:border-status-error-shape-default`

---

## Modal

```tsx
import { Modal } from "@/components/ui/modal/modal";

<Modal isOpen={open} onClose={() => setOpen(false)}>
  <Modal.Header
    title="캠페인 삭제"
    description="삭제 후 복구할 수 없습니다."
  />
  <Modal.Content className="px-xl py-md">
    {/* body content */}
  </Modal.Content>
  <Modal.BottomSheet
    buttons={[
      { variant: "mono", children: "취소" },
      { variant: "primary", intent: "danger", children: "삭제", closeOnClick: false, onClick: handleDelete },
    ]}
  />
</Modal>

// Props
// isOpen: boolean
// onClose: () => void
// closeOnOutsideClick?: boolean (default: true)
```

---

## Table

```tsx
import {
  Table, TableHeader, TableBody, TableRow,
  TableHead, TableCell, TableFooter
} from "@/components/ui/table/table";

<Table>
  <TableHeader>
    <TableRow>
      <TableHead>캠페인명</TableHead>
      <TableHead className="text-right">예산</TableHead>
      <TableHead>상태</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    {rows.map((row) => (
      <TableRow key={row.id}>
        <TableCell className="font-medium">{row.name}</TableCell>
        <TableCell className="text-right">{row.budget.toLocaleString()}원</TableCell>
        <TableCell><Badge color={row.statusColor}>{row.status}</Badge></TableCell>
      </TableRow>
    ))}
  </TableBody>
</Table>

// TableHeader is sticky (sticky top-0 bg-base-bg-subtle-emphasis)
// Use containerClassName for scrollable wrapper height
<Table containerClassName="max-h-[500px]">
```

---

## Frame (Card)

```tsx
import { Frame } from "@/components/ui/frame/frame";

// Basic card wrapper
<Frame className="p-xl">
  <h2 className="text-title-md">캠페인 설정</h2>
  {/* content */}
</Frame>

// Frame uses bg-base-bg-default, rounded-md, border-base-stroke-subtle by default
```

---

## Spinner

```tsx
import Spinner from "@/components/ui/loading/spinner/spinner";

<Spinner />           // default size (24px)
<Spinner size={20} /> // custom px size
```

---

## Chip (filter tags)

```tsx
import { Chip } from "@/components/ui/chip/chip";

<Chip selected={isSelected} onClick={toggle}>전체</Chip>
<Chip selected={false} onClick={toggle}>충전</Chip>
```

---

## Select

```tsx
import { Select } from "@/components/ui/select/select";

<Select
  options={[
    { value: "all", label: "전체" },
    { value: "active", label: "진행중" },
  ]}
  value={selected}
  onChange={setSelected}
  placeholder="선택하세요"
/>
```

---

## Pagination

```tsx
import { Pagination } from "@/components/ui/pagination/pagination";

<Pagination
  currentPage={page}
  totalPages={totalPages}
  onPageChange={setPage}
/>
```

---

## Tooltip

```tsx
import { Tooltip } from "@/components/ui/tooltip/tooltip";

<Tooltip content="자세한 설명입니다">
  <span>hover me</span>
</Tooltip>

// Default: side="bottom", align="start", delayDuration=0
```

---

## Snackbar / Toast

```tsx
import { useToast } from "@/components/ui/toast/use-toast"; // or similar

// Toast is triggered programmatically — do not build inline
toast({ title: "저장되었습니다", variant: "success" });
toast({ title: "오류가 발생했습니다", variant: "error" });
```

---

## Helper Text

```tsx
import { HelperText } from "@/components/ui/helper-text/helper-text";

<HelperText>최소 10,000원 이상 입력하세요</HelperText>
<HelperText error>금액을 확인해주세요</HelperText>
```

---

## Label + RequiredMark

```tsx
import { Label } from "@/components/ui/label/label";
import { RequiredMark } from "@/components/ui/required-mark/required-mark";

<Label htmlFor="budget">
  총 예산 <RequiredMark />
</Label>
<Input id="budget" type="number" />
```
