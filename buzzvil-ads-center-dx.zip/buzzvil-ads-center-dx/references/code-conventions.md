# Code Conventions

## Project Stack
- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript (strict)
- **Styling**: Tailwind CSS v4 + CSS custom properties
- **Components**: shadcn/ui (wrapped by Buzzvil UI layer)
- **Linter**: Biome

---

## File Structure

```
src/
├── app/                    ← Next.js pages (App Router)
│   └── ads/
│       └── [feature]/
│           └── page.tsx
├── components/
│   ├── shadcn-ui/         ← Radix primitives + token styling (don't touch)
│   └── ui/                ← Buzzvil components (use these)
│       ├── button/button.tsx
│       ├── badge/badge.tsx
│       ├── input/input.tsx
│       ├── modal/modal.tsx
│       ├── table/table.tsx
│       └── ...
├── styles/
│   ├── buzzvil-tokens.css  ← CSS custom properties (source of truth)
│   └── globals.css         ← Tailwind @theme block
└── types/
    └── icon.ts             ← IconInterface { size, className }
```

---

## Component File Convention

```tsx
"use client"; // required for hooks, event handlers, browser APIs

// 1. External imports
import type * as React from "react";
import { useState, useEffect } from "react";

// 2. Internal component imports
import { Button } from "@/components/ui/button/button";
import { Badge } from "@/components/ui/badge/badge";

// 3. Utility imports
import { cn } from "@/lib/utils";

// 4. Type definitions
type SomeStatus = "active" | "paused" | "ended";

interface SomeProps {
  id: string;
  name: string;
  status: SomeStatus;
  onEdit?: () => void;
}

// 5. Sub-components or helpers (if needed)
function SomeSubComponent({ ... }) { ... }

// 6. Main component
export default function SomeComponent({ id, name, status, onEdit }: SomeProps) {
  const [state, setState] = useState(false);

  return (
    <div>...</div>
  );
}

// 7. Named exports (for non-default exports)
export { SomeSubComponent };
```

---

## Naming Conventions

| Item | Convention | Example |
|------|-----------|---------|
| Components | PascalCase | `CampaignTable`, `PrepaidChargingPage` |
| Files | kebab-case | `campaign-table.tsx`, `prepaid-charging-page.tsx` |
| Props types | PascalCase + Props | `CampaignTableProps` |
| Event handlers | `handle` prefix | `handleSave`, `handleDelete` |
| Boolean state | `is/has/show` prefix | `isLoading`, `hasError`, `showModal` |
| Constants | SCREAMING_SNAKE | `PAGE_SIZE`, `MAX_BUDGET` |

---

## Class Naming (cn utility)

Always use `cn()` for conditional class merging:

```tsx
import { cn } from "@/lib/utils";

<div className={cn(
  "base-classes",
  isActive && "active-classes",
  isError && "error-classes",
  className, // always last, for overrides
)} />
```

---

## Korean UI Text Guidelines

- Button labels: concise verbs — `저장`, `취소`, `삭제`, `확인`, `수정`, `추가`
- Error messages: polite, specific — `금액을 확인해주세요`
- Empty states: constructive — `데이터가 없습니다. 새로 추가해보세요`
- Loading: `불러오는 중...`
- Confirmation modals: title as question — `삭제할까요?`

---

## Accessibility

- Always pair `<Label htmlFor>` with `<Input id>`
- Use `aria-invalid` for error states (not just red border)
- Use `aria-busy` for loading states (Button handles this automatically)
- Use semantic HTML: `<table>`, `<thead>`, `<th scope="col">` etc.

---

## Anti-patterns to Avoid

```tsx
// ❌ Hardcoded colors
<div style={{ color: "#3b82f6" }} />
<div className="bg-blue-500" />
<div className="text-slate-900" />

// ✅ Tokens
<div className="text-primary-fg-text-default" />
<div className="bg-primary-bg-default" />
<div className="text-base-fg-text-moderate-emphasis" />

// ❌ Direct Radix imports in pages
import * as Dialog from "@radix-ui/react-dialog";

// ✅ Use Buzzvil UI layer
import { Modal } from "@/components/ui/modal/modal";

// ❌ Tailwind v3 arbitrary values for tokens
<div className="bg-[#3b82f6]" />

// ✅ Named utility
<div className="bg-primary-bg-default" />
```

---

## Mock Data Pattern

When building prototype screens, use realistic Korean mock data:

```tsx
const MOCK_CAMPAIGNS = [
  {
    id: "CPG-001",
    name: "오아오아 브랜드 캠페인",
    budget: 5000000,
    spent: 2300000,
    status: "active" as const,
    startDate: "2026.03.01",
    endDate: "2026.03.31",
  },
  // ... 4-8 more rows
];
```
